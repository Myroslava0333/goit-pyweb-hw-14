
import os

from dotenv import load_dotenv
from fastapi_mail import (
    ConnectionConfig,
    FastMail,
    MessageSchema,
    MessageType,
)

load_dotenv()


conf = ConnectionConfig(
    MAIL_USERNAME=os.getenv("MAIL_USERNAME"),
    MAIL_PASSWORD=os.getenv("MAIL_PASSWORD"),
    MAIL_FROM=os.getenv("MAIL_FROM"),
    MAIL_PORT=int(os.getenv("MAIL_PORT", "587")),
    MAIL_SERVER=os.getenv("MAIL_SERVER"),
    MAIL_FROM_NAME=os.getenv(
        "MAIL_FROM_NAME",
        "Contacts API",
    ),
    MAIL_STARTTLS=os.getenv(
        "MAIL_STARTTLS",
        "True",
    ).lower() == "true",
    MAIL_SSL_TLS=os.getenv(
        "MAIL_SSL_TLS",
        "False",
    ).lower() == "true",
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=True,
)


async def send_verification_email(
    email: str,
    token: str,
):
    """
    Send an email verification message to a user.

    Generates a verification URL using the backend address
    and the provided JWT token, then sends an HTML email
    through the configured SMTP server.

    Args:
        email: Recipient's email address.
        token: JWT token used to verify the email address.

    Returns:
        None: The function sends the email without returning a value.

    Raises:
        Exception: If the email cannot be sent because of
            an SMTP connection or delivery error.
    """
    backend_url = os.getenv(
        "BACKEND_URL",
        "http://127.0.0.1:8000",
    )

    verification_url = (
        f"{backend_url}/auth/verify-email"
        f"?token={token}"
    )

    message = MessageSchema(
        subject="Email verification",
        recipients=[email],
        body=f"""
        <html>
            <body>
                <h2>Welcome to Contacts API!</h2>

                <p>
                    Please confirm your email address.
                </p>

                <a href="{verification_url}">
                    Verify email
                </a>
            </body>
        </html>
        """,
        subtype=MessageType.html,
    )

    fast_mail = FastMail(conf)

    await fast_mail.send_message(message)
