
import os
from datetime import datetime, timedelta, timezone

from jose import JWTError, jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from dotenv import load_dotenv

load_dotenv()

SECRET_KEY = os.getenv("JWT_SECRET_KEY")

if not SECRET_KEY or len(SECRET_KEY) < 32:
    raise RuntimeError("JWT_SECRET_KEY must contain at least 32 characters")

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

password_hasher = PasswordHasher()


def get_password_hash(password: str) -> str:
    """
    Generate a secure Argon2 hash for the given password.

    Args:
        password: Plain-text password to hash.

    Returns:
        str: Hashed password.
    """
    return password_hasher.hash(password)


def verify_password(
    plain_password: str,
    hashed_password: str,
) -> bool:
    """
    Verify a plain-text password against its stored hash.

    Args:
        plain_password: Password provided by the user.
        hashed_password: Previously generated password hash.

    Returns:
        bool: True if the password matches the hash, otherwise False.
    """
    try:
        return password_hasher.verify(
            hashed_password,
            plain_password,
        )
    except (VerifyMismatchError, VerificationError):
        return False


def create_access_token(data: dict) -> str:
    """
    Create a JWT access token with a limited expiration time.

    Args:
        data: Dictionary containing the payload to encode.

    Returns:
        str: Encoded JWT access token.
    """
    to_encode = data.copy()

    expire = datetime.now(timezone.utc) + timedelta(
        minutes=ACCESS_TOKEN_EXPIRE_MINUTES
    )

    to_encode.update({
        "exp": expire,
        "type": "access",
    })

    return jwt.encode(
        to_encode,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def create_refresh_token(data: dict) -> str:
    """
    Create a JWT refresh token with a longer expiration time.

    Args:
        data: Dictionary containing the payload to encode.

    Returns:
        str: Encoded JWT refresh token.
    """
    to_encode = data.copy()

    expire = datetime.now(timezone.utc) + timedelta(
        days=REFRESH_TOKEN_EXPIRE_DAYS
    )

    to_encode.update({
        "exp": expire,
        "type": "refresh",
    })

    return jwt.encode(
        to_encode,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def decode_token(token: str):
    """
    Decode and validate a JWT token.

    Args:
        token: Encoded JWT token.

    Returns:
        dict | None: Decoded token payload if valid, otherwise None.
    """
    try:
        return jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],
        )
    except JWTError:
        return None
