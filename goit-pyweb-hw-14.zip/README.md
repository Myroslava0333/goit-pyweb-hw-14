﻿
# Contacts REST API

## Опис проєкту

REST API застосунок для керування особистими контактами з автентифікацією та авторизацією користувачів.

Кожен користувач може керувати лише власними контактами.

## Функціональність

### Authentication
- Реєстрація користувачів.
- Вхід за email і паролем.
- JWT Access та Refresh токени.
- Хешування паролів за допомогою Argon2.
- Верифікація електронної пошти.
- Повторне надсилання листа підтвердження.
- Отримання інформації про поточного користувача.

### Contacts
- Створення контактів.
- Перегляд усіх контактів.
- Пошук контактів.
- Перегляд контакту за ID.
- Оновлення та часткове оновлення.
- Видалення контактів.
- Перегляд найближчих днів народження.

### Rate Limiting
- Обмеження створення контактів: 5 запитів за хвилину.
- Обмеження інших маршрутів контактів: 30 запитів за хвилину.
- Ідентифікація користувача за токеном авторизації.

### CORS
- Налаштування дозволених джерел через змінні середовища.

### User Avatar
- Завантаження аватара.
- Перевірка формату зображення.
- Обмеження розміру файлу до 5 MB.
- Зберігання зображень у Cloudinary.

## Технології

- Python 3.14
- FastAPI
- SQLAlchemy
- PostgreSQL
- Pydantic
- JWT
- Argon2
- FastAPI-Mail
- SlowAPI
- Cloudinary
- Docker
- Docker Compose
- Pipenv

## Встановлення

1. Клонувати репозиторій.
2. Створити `.env` на основі `.env.example`.
3. Заповнити змінні середовища.
4. Запустити Docker Compose.

```bash
docker compose up --build -d
```

## Перевірка контейнерів

```bash
docker compose ps
```

## Перегляд логів

```bash
docker compose logs -f web
```

## API Documentation

Swagger:

http://127.0.0.1:8000/docs

ReDoc:

http://127.0.0.1:8000/redoc

## Основні маршрути

### Authentication

- POST `/auth/register`
- GET `/auth/verify-email`
- POST `/auth/resend-verification`
- POST `/auth/login`
- POST `/auth/refresh`
- GET `/auth/me`

### Contacts

- POST `/contacts/`
- GET `/contacts/`
- GET `/contacts/birthdays/`
- GET `/contacts/{contact_id}`
- PUT `/contacts/{contact_id}`
- PATCH `/contacts/{contact_id}`
- DELETE `/contacts/{contact_id}`

### Users

- POST `/users/avatar`

## Database

PostgreSQL використовується як основна база даних.

SQLAlchemy ORM використовується для роботи з моделями User та Contact.

## Email Verification

Під час реєстрації користувач отримує лист із посиланням для підтвердження електронної пошти.

Авторизація доступна лише після підтвердження email.

## Cloudinary

Аватари користувачів завантажуються у Cloudinary.

Посилання на зображення зберігається у полі `avatar_url`.

## Docker

Усі сервіси запускаються через Docker Compose.

## Environment Variables

Конфіденційні налаштування зберігаються у `.env`.

Файл `.env` не додається до Git та ZIP-архіву.

## Author

Myroslava

GoIT Python Web Development

Homework #14

