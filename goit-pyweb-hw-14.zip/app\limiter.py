
from slowapi import Limiter
from slowapi.util import get_remote_address

from .auth import decode_token


def get_user_rate_limit_key(request):
    """
    Determine the rate-limiting key for an incoming request.

    Authenticated users are identified by their user ID from the access token.
    Requests without a valid access token are identified by their IP address.

    Args:
        request: Incoming HTTP request.

    Returns:
        str: Rate-limiting key based on the user ID or IP address.
    """
    authorization = request.headers.get("Authorization", "")

    if authorization.startswith("Bearer "):
        token = authorization.split(" ", 1)[1]

        payload = decode_token(
            token,
            expected_type="access",
        )

        if payload:
            user_id = payload.get("sub")

            if user_id:
                return f"user:{user_id}"

    return get_remote_address(request)


limiter = Limiter(
    key_func=get_user_rate_limit_key,
    storage_uri="memory://",
)