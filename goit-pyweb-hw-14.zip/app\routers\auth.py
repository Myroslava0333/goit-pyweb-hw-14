
import logging

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
)

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auth import (
    create_access_token,
    create_refresh_token,
    create_email_verification_token,
    decode_token,
    get_password_hash,
    verify_password,
)

from ..database import get_db
from ..dependencies import get_current_user
from ..models import Contact, User

from ..schemas import (
    RefreshTokenRequest,
    TokenResponse,
    UserCreate,
    UserLogin,
    UserResponse,
    EmailRequest,
)

from ..services.email import send_verification_email


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"],
)


def create_token_pair(user_id: int) -> TokenResponse:
    """
    Create an access token and a refresh token for a user.

    Args:
        user_id: ID of the authenticated user.

    Returns:
        TokenResponse: Object containing access and refresh tokens.
    """
    return TokenResponse(
        access_token=create_access_token(user_id),
        refresh_token=create_refresh_token(user_id),
    )


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
async def register_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
):
    """
    Register a new user and send an email verification link.

    Checks whether the email is already registered, hashes the password,
    creates the user account and sends a verification email.

    Args:
        user_data: Registration data containing the email and password.
        db: Database session.

    Returns:
        UserResponse: Newly created user information.

    Raises:
        HTTPException: If the email is already registered or
            the verification email cannot be sent.
    """
    existing_user = db.scalar(
        select(User).where(
            User.email == user_data.email.lower()
        )
    )

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User with this email already exists",
        )

    user = User(
        email=user_data.email.lower(),
        hashed_password=get_password_hash(
            user_data.password
        ),
        is_verified=False,
    )

    db.add(user)

    try:
        db.flush()

        db.execute(
            update(Contact)
            .where(Contact.user_id.is_(None))
            .values(user_id=user.id)
        )

        db.commit()
        db.refresh(user)

    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User with this email already exists",
        )

    token = create_email_verification_token(user.id)

    try:
        await send_verification_email(
            user.email,
            token,
        )

    except Exception:
        logger.exception(
            "Failed to send verification email during registration"
        )

        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "User registered, but verification "
                "email could not be sent"
            ),
        )

    return user


@router.get("/verify-email")
def verify_email(
    token: str,
    db: Session = Depends(get_db),
):
    """
    Verify a user's email address using a verification token.

    Args:
        token: JWT email verification token.
        db: Database session.

    Returns:
        dict: Message indicating the email verification result.

    Raises:
        HTTPException: If the token is invalid, expired or
            the user does not exist.
    """
    payload = decode_token(
        token,
        expected_type="email_verification",
    )

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired verification token",
        )

    try:
        user_id = int(payload.get("sub"))
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid verification token",
        )

    user = db.get(User, user_id)

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    if user.is_verified:
        return {
            "message": "Email already verified",
        }

    user.is_verified = True

    db.commit()

    return {
        "message": "Email successfully verified",
    }


@router.post("/resend-verification")
async def resend_verification(
    user_data: EmailRequest,
    db: Session = Depends(get_db),
):
    """
    Resend an email verification link to an unverified user.

    Args:
        user_data: Request containing the user's email address.
        db: Database session.

    Returns:
        dict: Message indicating the result of the operation.

    Raises:
        HTTPException: If the verification email cannot be sent.
    """
    user = db.scalar(
        select(User).where(
            User.email == user_data.email.lower()
        )
    )

    if user is None or user.is_verified:
        return {
            "message": (
                "If the account exists and needs verification, "
                "an email will be sent"
            )
        }

    token = create_email_verification_token(user.id)

    try:
        await send_verification_email(
            user.email,
            token,
        )

    except Exception:
        logger.exception(
            "Failed to resend verification email"
        )

        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Could not send verification email",
        )

    return {
        "message": "Verification email sent",
    }


@router.post(
    "/login",
    response_model=TokenResponse,
)
def login_user(
    user_data: UserLogin,
    db: Session = Depends(get_db),
):
    """
    Authenticate a user using email and password.

    Checks the user's credentials and email verification status.
    Returns a pair of JWT tokens if authentication is successful.

    Args:
        user_data: Login credentials containing email and password.
        db: Database session.

    Returns:
        TokenResponse: Access and refresh tokens.

    Raises:
        HTTPException: If credentials are invalid or email is not verified.
    """
    user = db.scalar(
        select(User).where(
            User.email == user_data.email.lower()
        )
    )

    if user is None or not verify_password(
        user_data.password,
        user.hashed_password,
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Please verify your email first",
        )

    return create_token_pair(user.id)


@router.post(
    "/refresh",
    response_model=TokenResponse,
)
def refresh_tokens(
    token_data: RefreshTokenRequest,
    db: Session = Depends(get_db),
):
    """
    Generate a new pair of JWT tokens using a refresh token.

    Validates the refresh token and checks whether the associated
    user exists and has a verified email address.

    Args:
        token_data: Request containing the refresh token.
        db: Database session.

    Returns:
        TokenResponse: New access and refresh tokens.

    Raises:
        HTTPException: If the refresh token is invalid or the user
            does not exist or is not verified.
    """
    payload = decode_token(
        token_data.refresh_token,
        expected_type="refresh",
    )

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )

    try:
        user_id = int(payload.get("sub"))
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )

    user = db.get(User, user_id)

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )

    if not user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Email is not verified",
        )

    return create_token_pair(user.id)


@router.get(
    "/me",
    response_model=UserResponse,
)
def get_me(
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve information about the currently authenticated user.

    Args:
        current_user: Authenticated user obtained from the access token.

    Returns:
        UserResponse: Information about the current user.
    """
    return current_user
