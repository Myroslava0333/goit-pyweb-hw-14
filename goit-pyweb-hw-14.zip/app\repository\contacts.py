
"""
Repository functions for managing contacts in the database.
"""

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.models import Contact
from app.schemas import ContactCreate


def create_contact(
    db: Session,
    contact_data: ContactCreate,
    user_id: int,
) -> Contact:
    """
    Create a new contact for a specific user.

    Args:
        db: Database session.
        contact_data: Validated contact information.
        user_id: ID of the contact owner.

    Returns:
        The created contact.

    Raises:
        IntegrityError: If the contact violates a database constraint.
    """
    contact = Contact(
        **contact_data.model_dump(),
        user_id=user_id,
    )

    db.add(contact)

    try:
        db.commit()
        db.refresh(contact)
    except Exception:
        db.rollback()
        raise

    return contact


def get_contact_by_id(
    db: Session,
    contact_id: int,
    user_id: int,
) -> Contact | None:
    """
    Find a contact by its ID and owner ID.

    Args:
        db: Database session.
        contact_id: Contact ID.
        user_id: Owner's user ID.

    Returns:
        The contact if found, otherwise None.
    """
    return db.scalar(
        select(Contact).where(
            Contact.id == contact_id,
            Contact.user_id == user_id,
        )
    )


def get_contacts(
    db: Session,
    user_id: int,
    search: str | None = None,
    first_name: str | None = None,
    last_name: str | None = None,
    email: str | None = None,
) -> list[Contact]:
    """
    Retrieve contacts belonging to a user with optional filters.

    Args:
        db: Database session.
        user_id: Owner's user ID.
        search: General search term.
        first_name: First name filter.
        last_name: Last name filter.
        email: Email filter.

    Returns:
        A list of matching contacts.
    """
    statement = select(Contact).where(
        Contact.user_id == user_id
    )

    if search:
        search_term = f"%{search}%"

        statement = statement.where(
            or_(
                Contact.first_name.ilike(search_term),
                Contact.last_name.ilike(search_term),
                Contact.email.ilike(search_term),
            )
        )

    if first_name:
        statement = statement.where(
            Contact.first_name.ilike(f"%{first_name}%")
        )

    if last_name:
        statement = statement.where(
            Contact.last_name.ilike(f"%{last_name}%")
        )

    if email:
        statement = statement.where(
            Contact.email.ilike(f"%{email}%")
        )

    statement = statement.order_by(Contact.id)

    return db.scalars(statement).all()


def update_contact(
    db: Session,
    contact: Contact,
    update_data: dict,
) -> Contact:
    """
    Update the provided fields of an existing contact.

    Args:
        db: Database session.
        contact: Contact to update.
        update_data: Fields and their new values.

    Returns:
        The updated contact.
    """
    for field, value in update_data.items():
        setattr(contact, field, value)

    try:
        db.commit()
        db.refresh(contact)
    except Exception:
        db.rollback()
        raise

    return contact


def delete_contact(
    db: Session,
    contact: Contact,
) -> None:
    """
    Delete a contact from the database.

    Args:
        db: Database session.
        contact: Contact to delete.
    """
    db.delete(contact)
    db.commit()
