
import os
import sys

# Add the project root to the Python path.
sys.path.insert(
    0,
    os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")),
)

# Test environment variables for Sphinx documentation.
# These values are only for documentation generation.
os.environ.setdefault(
    "DATABASE_URL",
    "sqlite:///./docs.db",
)

os.environ.setdefault(
    "JWT_SECRET_KEY",
    "sphinx-documentation-test-secret-key-123456789",
)

os.environ.setdefault("JWT_ALGORITHM", "HS256")

os.environ.setdefault("MAIL_USERNAME", "docs@example.com")
os.environ.setdefault("MAIL_PASSWORD", "documentation-test-password")
os.environ.setdefault("MAIL_FROM", "docs@example.com")
os.environ.setdefault("MAIL_SERVER", "smtp.example.com")
os.environ.setdefault("MAIL_PORT", "587")
os.environ.setdefault("MAIL_FROM_NAME", "Sphinx Documentation")

project = "GoIT Python Web Homework 14"
copyright = "2026, Myroslava"
author = "Myroslava"
release = "1.0"

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.viewcode",
]

templates_path = ["_templates"]
exclude_patterns = []

language = "uk"

autodoc_default_options = {
    "members": True,
    "undoc-members": True,
    "show-inheritance": True,
}

html_theme = "alabaster"
html_static_path = ["_static"]
