
from datetime import date, timedelta

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.limiter import limiter
from app.models import Contact, User
from app.schemas import (
    ContactCreate,
    ContactResponse,
    ContactUpdate,
)
from app.repository.contacts import (
    create_contact as repository_create_contact,
    get_contact_by_id,
    get_contacts as repository_list_contacts,
    update_contact as repository_update_contact,
    delete_contact as repository_delete_contact,
)


router = APIRouter(
    prefix="/contacts",
    tags=["Contacts"],
)


def get_next_birthday(birthday: date, today: date) -> date:
    """
    Calculate the next occurrence of a contact's birthday.

    Handles birthdays on February 29 in non-leap years.

    Args:
        birthday: Contact's date of birth.
        today: Current date used as the calculation reference.

    Returns:
        date: Date of the next birthday.
    """
    try:
        next_birthday = birthday.replace(year=today.year)
    except ValueError:
        next_birthday = birthday.replace(
            year=today.year,
            day=28,
        )

    if next_birthday < today:
        try:
            next_birthday = birthday.replace(
                year=today.year + 1
            )
        except ValueError:
            next_birthday = birthday.replace(
                year=today.year + 1,
                day=28,
            )

    return next_birthday


def get_contact_or_404(
    contact_id: int,
    db: Session,
    current_user: User,
) -> Contact:
    """
    Retrieve a contact belonging to the current user.

    Args:
        contact_id: ID of the contact to retrieve.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        Contact: Retrieved contact.

    Raises:
        HTTPException: If the contact does not exist or
            does not belong to the current user.
    """
    contact = get_contact_by_id(
        db=db,
        contact_id=contact_id,
        user_id=current_user.id,
    )

    if contact is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found",
        )

    return contact


@router.post(
    "/",
    response_model=ContactResponse,
    status_code=status.HTTP_201_CREATED,
)
@limiter.limit("5/minute")
def create_contact(
    request: Request,
    contact_data: ContactCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Create a new contact for the currently authenticated user.

    Args:
        request: Incoming HTTP request.
        contact_data: Data required to create a contact.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        ContactResponse: Newly created contact.

    Raises:
        HTTPException: If a contact with the same email already exists.
    """
    try:
        return repository_create_contact(
            db=db,
            contact_data=contact_data,
            user_id=current_user.id,
        )
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Contact with this email already exists",
        )


@router.get(
    "/birthdays/",
    response_model=list[ContactResponse],
)
@limiter.limit("30/minute")
def get_upcoming_birthdays(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve contacts whose birthdays occur within the next seven days.

    Args:
        request: Incoming HTTP request.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        list[ContactResponse]: Contacts sorted by their upcoming birthdays.
    """
    today = date.today()
    end_date = today + timedelta(days=7)

    statement = select(Contact).where(
        Contact.user_id == current_user.id
    )

    contacts = db.scalars(statement).all()

    upcoming_contacts = []

    for contact in contacts:
        next_birthday = get_next_birthday(
            contact.birthday,
            today,
        )

        if today <= next_birthday <= end_date:
            upcoming_contacts.append(
                (next_birthday, contact)
            )

    upcoming_contacts.sort(
        key=lambda item: item[0]
    )

    return [
        contact
        for _, contact in upcoming_contacts
    ]


@router.get(
    "/",
    response_model=list[ContactResponse],
)
@limiter.limit("30/minute")
def get_contacts(
    request: Request,
    search: str | None = Query(default=None),
    first_name: str | None = Query(default=None),
    last_name: str | None = Query(default=None),
    email: str | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve contacts belonging to the currently authenticated user.

    Supports filtering by a general search term, first name,
    last name and email address.

    Args:
        request: Incoming HTTP request.
        search: Optional general search term.
        first_name: Optional first name filter.
        last_name: Optional last name filter.
        email: Optional email address filter.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        list[ContactResponse]: List of matching contacts.
    """
    return repository_list_contacts(
        db=db,
        user_id=current_user.id,
        search=search,
        first_name=first_name,
        last_name=last_name,
        email=email,
    )


@router.get(
    "/{contact_id}",
    response_model=ContactResponse,
)
@limiter.limit("30/minute")
def get_contact(
    request: Request,
    contact_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve a specific contact by its ID.

    Args:
        request: Incoming HTTP request.
        contact_id: ID of the contact to retrieve.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        ContactResponse: Retrieved contact.

    Raises:
        HTTPException: If the contact is not found.
    """
    return get_contact_or_404(
        contact_id,
        db,
        current_user,
    )


@router.put(
    "/{contact_id}",
    response_model=ContactResponse,
)
@limiter.limit("30/minute")
def update_contact(
    request: Request,
    contact_id: int,
    contact_data: ContactCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Replace all editable fields of an existing contact.

    Args:
        request: Incoming HTTP request.
        contact_id: ID of the contact to update.
        contact_data: New contact data.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        ContactResponse: Updated contact.

    Raises:
        HTTPException: If the contact is not found or
            a contact with the same email already exists.
    """
    contact = get_contact_or_404(
        contact_id,
        db,
        current_user,
    )

    try:
        return repository_update_contact(
            db=db,
            contact=contact,
            update_data=contact_data.model_dump(),
        )
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Contact with this email already exists",
        )


@router.patch(
    "/{contact_id}",
    response_model=ContactResponse,
)
@limiter.limit("30/minute")
def partially_update_contact(
    request: Request,
    contact_id: int,
    contact_data: ContactUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Partially update an existing contact.

    Only fields explicitly provided in the request are updated.

    Args:
        request: Incoming HTTP request.
        contact_id: ID of the contact to update.
        contact_data: Contact fields to update.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        ContactResponse: Updated contact.

    Raises:
        HTTPException: If the contact is not found, a field contains
            an invalid null value, or the email already exists.
    """
    contact = get_contact_or_404(
        contact_id,
        db,
        current_user,
    )

    update_data = contact_data.model_dump(
        exclude_unset=True
    )

    for field, value in update_data.items():
        if value is None and field != "additional_data":
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"{field} cannot be null",
            )

    try:
        return repository_update_contact(
            db=db,
            contact=contact,
            update_data=update_data,
        )
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Contact with this email already exists",
        )


@router.delete(
    "/{contact_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
@limiter.limit("30/minute")
def delete_contact(
    request: Request,
    contact_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Delete a contact belonging to the currently authenticated user.

    Args:
        request: Incoming HTTP request.
        contact_id: ID of the contact to delete.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        Response: HTTP 204 No Content response.

    Raises:
        HTTPException: If the contact is not found.
    """
    contact = get_contact_or_404(
        contact_id,
        db,
        current_user,
    )

    repository_delete_contact(
        db=db,
        contact=contact,
    )

    return Response(
        status_code=status.HTTP_204_NO_CONTENT
    )
