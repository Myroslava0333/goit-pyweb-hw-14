
from contextlib import asynccontextmanager
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from . import models
from .database import Base, engine
from .limiter import limiter

from .routers.auth import router as auth_router
from .routers.contacts import router as contacts_router
from .routers.users import router as users_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Manage the application lifespan.

    Create database tables and apply required database schema updates
    when the application starts.
    """
    Base.metadata.create_all(bind=engine)

    with engine.begin() as connection:
        connection.execute(
            text(
                """
                ALTER TABLE contacts
                ADD COLUMN IF NOT EXISTS user_id
                INTEGER REFERENCES users(id) ON DELETE CASCADE
                """
            )
        )

        connection.execute(
            text(
                """
                CREATE INDEX IF NOT EXISTS ix_contacts_user_id
                ON contacts (user_id)
                """
            )
        )

        connection.execute(
            text(
                """
                ALTER TABLE users
                ADD COLUMN IF NOT EXISTS avatar_url VARCHAR(500)
                """
            )
        )

    yield


app = FastAPI(
    title="Contacts REST API",
    description=(
        "REST API for managing contacts, "
        "user authentication and JWT authorization."
    ),
    version="2.0.0",
    lifespan=lifespan,
)


# Rate Limiting
app.state.limiter = limiter

app.add_exception_handler(
    RateLimitExceeded,
    _rate_limit_exceeded_handler,
)


# CORS
origins = [
    origin.strip()
    for origin in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if origin.strip()
]


app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Routers
app.include_router(auth_router)
app.include_router(contacts_router)
app.include_router(users_router)


@app.get("/", tags=["Root"])
def root():
    """
    Return the API welcome message and documentation links.

    Returns:
        dict: API status message and links to Swagger UI and ReDoc.
    """
    return {
        "message": "Contacts API is running",
        "documentation": "/docs",
        "redoc": "/redoc",
    }
