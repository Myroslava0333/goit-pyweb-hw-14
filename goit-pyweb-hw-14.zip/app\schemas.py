
"""
Pydantic-схеми для роботи з контактами та користувачами.

Модуль містить схеми валідації вхідних даних і формування
відповідей API для контактів, користувачів та автентифікації.
"""

from datetime import date

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
)


class ContactBase(BaseModel):
    """Базова схема контакту з основними персональними даними."""

    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=3, max_length=30)
    birthday: date
    additional_data: str | None = None


class ContactCreate(ContactBase):
    """Схема для створення нового контакту."""

    pass


class ContactUpdate(BaseModel):
    """Схема для часткового оновлення даних контакту."""

    first_name: str | None = Field(
        default=None,
        min_length=1,
        max_length=100,
    )

    last_name: str | None = Field(
        default=None,
        min_length=1,
        max_length=100,
    )

    email: EmailStr | None = None
    phone: str | None = Field(
        default=None,
        min_length=3,
        max_length=30,
    )

    birthday: date | None = None
    additional_data: str | None = None


class ContactResponse(ContactBase):
    """Схема відповіді API з даними контакту та його ідентифікатором."""

    id: int

    model_config = ConfigDict(from_attributes=True)


class UserCreate(BaseModel):
    """Схема реєстрації користувача."""

    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserLogin(BaseModel):
    """Схема авторизації користувача за електронною поштою та паролем."""

    email: EmailStr
    password: str


class UserResponse(BaseModel):
    """Схема відповіді API з основними даними користувача."""

    id: int
    email: EmailStr
    is_verified: bool
    avatar_url: str | None = None

    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    """Схема відповіді з токенами доступу та оновлення."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshTokenRequest(BaseModel):
    """Схема запиту на оновлення токена доступу."""

    refresh_token: str


class EmailRequest(BaseModel):
    """Схема запиту, що містить адресу електронної пошти."""

    email: EmailStr
