
import os

# Test environment variables.
os.environ.setdefault(
    "DATABASE_URL",
    "sqlite:///./test.db",
)

os.environ.setdefault(
    "JWT_SECRET_KEY",
    "test-secret-key-for-pytest-only",
)

# Test email configuration.
os.environ.setdefault("MAIL_USERNAME", "test@example.com")
os.environ.setdefault("MAIL_PASSWORD", "test-password")
os.environ.setdefault("MAIL_FROM", "test@example.com")
os.environ.setdefault("MAIL_SERVER", "localhost")

from datetime import date
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.main import app
from app.database import get_db
from app.dependencies import get_current_user
from app.models import Contact, User
from app.routers import contacts as contacts_router


@pytest.fixture
def client():
    """Create a test client with overridden dependencies."""

    def override_get_db():
        yield MagicMock(spec=Session)

    def override_get_current_user():
        return User(
            id=1,
            email="test@example.com",
            hashed_password="test_password",
            is_verified=True,
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = (
        override_get_current_user
    )

    # Do not use the TestClient as a context manager.
    # This prevents the production database lifespan from running.
    test_client = TestClient(app)

    yield test_client

    app.dependency_overrides.clear()


def test_get_contacts_returns_contacts(client, monkeypatch):
    """Test retrieving contacts for the authenticated user."""

    test_contact = Contact(
        id=1,
        first_name="Olena",
        last_name="Koval",
        email="olena@example.com",
        phone="+380991234567",
        birthday=date(1995, 11, 4),
        additional_data="Test contact",
        user_id=1,
    )

    def mock_get_contacts(**kwargs):
        assert kwargs["user_id"] == 1
        return [test_contact]

    monkeypatch.setattr(
        contacts_router,
        "repository_list_contacts",
        mock_get_contacts,
    )

    response = client.get("/contacts/")

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["id"] == 1
    assert data[0]["first_name"] == "Olena"
    assert data[0]["last_name"] == "Koval"
    assert data[0]["email"] == "olena@example.com"
    assert data[0]["phone"] == "+380991234567"
    assert data[0]["birthday"] == "1995-11-04"
