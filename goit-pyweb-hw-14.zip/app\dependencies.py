
"""
Модуль залежностей FastAPI.

Містить залежність get_current_user, яка перевіряє токен
авторизації, знаходить користувача в базі даних і перевіряє
статус верифікації його електронної пошти.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBearer,
)
from sqlalchemy.orm import Session

from .auth import decode_token
from .database import get_db
from .models import User


bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    ),
    db: Session = Depends(get_db),
) -> User:
    """
    Отримує поточного автентифікованого користувача.

    Перевіряє наявність і дійсність access-токена, отримує
    ідентифікатор користувача та перевіряє його наявність
    і верифікацію електронної пошти.

    Args:
        credentials: Дані Bearer-авторизації.
        db: Сесія бази даних.

    Returns:
        User: Об'єкт поточного користувача.

    Raises:
        HTTPException: Якщо токен відсутній або недійсний,
            користувача не знайдено чи його електронну пошту
            не верифіковано.
    """

    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if credentials is None:
        raise unauthorized

    payload = decode_token(
        credentials.credentials,
        expected_type="access",
    )

    if payload is None:
        raise unauthorized

    try:
        user_id = int(payload.get("sub"))
    except (TypeError, ValueError):
        raise unauthorized

    user = db.get(User, user_id)

    if user is None:
        raise unauthorized

    if not user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Email is not verified",
        )

    return user
