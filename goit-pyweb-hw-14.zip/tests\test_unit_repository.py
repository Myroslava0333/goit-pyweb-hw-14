
import os
import unittest
from datetime import date
from unittest.mock import MagicMock

# Test database configuration.
os.environ.setdefault(
    "DATABASE_URL",
    "sqlite:///./test.db",
)

from sqlalchemy.orm import Session

from app.models import Contact, User
from app.schemas import ContactCreate
from app.repository.contacts import (
    create_contact,
    get_contact_by_id,
    get_contacts,
    update_contact,
    delete_contact,
)


class TestContactsRepository(unittest.TestCase):
    """Unit tests for contact repository functions."""

    def setUp(self):
        """Set up mocked database session and test user."""

        self.db = MagicMock(spec=Session)

        self.user = User(
            id=1,
            email="test@example.com",
            hashed_password="test_password",
            is_verified=True,
        )

        self.contact = Contact(
            id=1,
            first_name="Olena",
            last_name="Koval",
            email="olena@example.com",
            phone="+380991234567",
            birthday=date(1995, 11, 4),
            additional_data="Test contact",
            user_id=1,
        )

    def test_create_contact(self):
        """Test creating a new contact."""

        contact_data = ContactCreate(
            first_name="Olena",
            last_name="Koval",
            email="olena@example.com",
            phone="+380991234567",
            birthday=date(1995, 11, 4),
            additional_data="Test contact",
        )

        result = create_contact(
            db=self.db,
            contact_data=contact_data,
            user_id=self.user.id,
        )

        self.assertEqual(result.first_name, "Olena")
        self.assertEqual(result.last_name, "Koval")
        self.assertEqual(result.email, "olena@example.com")
        self.assertEqual(result.user_id, self.user.id)

        self.db.add.assert_called_once_with(result)
        self.db.commit.assert_called_once()
        self.db.refresh.assert_called_once_with(result)

    def test_create_contact_rollback(self):
        """Test database rollback when contact creation fails."""

        contact_data = ContactCreate(
            first_name="Olena",
            last_name="Koval",
            email="olena@example.com",
            phone="+380991234567",
            birthday=date(1995, 11, 4),
        )

        self.db.commit.side_effect = RuntimeError(
            "Database error"
        )

        with self.assertRaises(RuntimeError):
            create_contact(
                db=self.db,
                contact_data=contact_data,
                user_id=self.user.id,
            )

        self.db.rollback.assert_called_once()

    def test_get_contact_by_id_found(self):
        """Test finding a contact by ID."""

        self.db.scalar.return_value = self.contact

        result = get_contact_by_id(
            db=self.db,
            contact_id=1,
            user_id=1,
        )

        self.assertEqual(result, self.contact)
        self.db.scalar.assert_called_once()

    def test_get_contact_by_id_not_found(self):
        """Test finding a contact that does not exist."""

        self.db.scalar.return_value = None

        result = get_contact_by_id(
            db=self.db,
            contact_id=999,
            user_id=1,
        )

        self.assertIsNone(result)
        self.db.scalar.assert_called_once()

    def test_get_contacts(self):
        """Test retrieving all contacts for a user."""

        contacts = [
            self.contact,
            Contact(
                id=2,
                first_name="Ivan",
                last_name="Petrenko",
                email="ivan@example.com",
                phone="+380991111111",
                birthday=date(1990, 5, 10),
                user_id=1,
            ),
        ]

        self.db.scalars.return_value.all.return_value = contacts

        result = get_contacts(
            db=self.db,
            user_id=1,
        )

        self.assertEqual(result, contacts)
        self.assertEqual(len(result), 2)
        self.db.scalars.assert_called_once()

    def test_get_contacts_with_filters(self):
        """Test retrieving contacts with search filters."""

        self.db.scalars.return_value.all.return_value = [
            self.contact
        ]

        result = get_contacts(
            db=self.db,
            user_id=1,
            search="Olena",
            first_name="Olena",
            last_name="Koval",
            email="example.com",
        )

        self.assertEqual(result, [self.contact])

        self.db.scalars.assert_called_once()

        statement = self.db.scalars.call_args[0][0]
        params = statement.compile().params

        self.assertIn("%Olena%", params.values())
        self.assertIn("%Koval%", params.values())
        self.assertIn("%example.com%", params.values())

    def test_update_contact(self):
        """Test updating an existing contact."""

        update_data = {
            "first_name": "Olena Updated",
            "phone": "+380999999999",
        }

        result = update_contact(
            db=self.db,
            contact=self.contact,
            update_data=update_data,
        )

        self.assertEqual(result.first_name, "Olena Updated")
        self.assertEqual(result.phone, "+380999999999")

        self.db.commit.assert_called_once()
        self.db.refresh.assert_called_once_with(self.contact)

    def test_update_contact_rollback(self):
        """Test database rollback when contact update fails."""

        self.db.commit.side_effect = RuntimeError(
            "Database error"
        )

        with self.assertRaises(RuntimeError):
            update_contact(
                db=self.db,
                contact=self.contact,
                update_data={"first_name": "Updated"},
            )

        self.db.rollback.assert_called_once()

    def test_delete_contact(self):
        """Test deleting an existing contact."""

        result = delete_contact(
            db=self.db,
            contact=self.contact,
        )

        self.assertIsNone(result)

        self.db.delete.assert_called_once_with(self.contact)
        self.db.commit.assert_called_once()


if __name__ == "__main__":
    unittest.main()
