
import os
from datetime import datetime, timedelta, timezone

import jwt
from dotenv import load_dotenv
from pwdlib import PasswordHash

load_dotenv()

SECRET_KEY = os.getenv("JWT_SECRET_KEY")

if not SECRET_KEY:
    raise RuntimeError("JWT_SECRET_KEY is not set in .env")

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = 15
REFRESH_TOKEN_EXPIRE_DAYS = 7

password_hash = PasswordHash.recommended()


def get_password_hash(password: str) -> str:
    """
    Hash a plain-text password using the recommended password hashing algorithm.

    Args:
        password: Plain-text password to hash.

    Returns:
        str: Hashed password.
    """
    return password_hash.hash(password)


def verify_password(
    plain_password: str,
    hashed_password: str,
) -> bool:
    """
    Verify a plain-text password against its stored hash.

    Args:
        plain_password: Password provided by the user.
        hashed_password: Previously generated password hash.

    Returns:
        bool: True if the password matches, otherwise False.
    """
    return password_hash.verify(
        plain_password,
        hashed_password,
    )


def create_token(
    user_id: int,
    token_type: str,
    expires_delta: timedelta,
) -> str:
    """
    Create a JWT token with the specified type and expiration time.

    Args:
        user_id: ID of the user associated with the token.
        token_type: Type of token, such as access, refresh or email_verification.
        expires_delta: Time interval after which the token expires.

    Returns:
        str: Encoded JWT token.
    """
    expire = datetime.now(timezone.utc) + expires_delta

    payload = {
        "sub": str(user_id),
        "type": token_type,
        "exp": expire,
    }

    return jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def create_access_token(user_id: int) -> str:
    """
    Create a short-lived JWT access token for a user.

    Args:
        user_id: ID of the user.

    Returns:
        str: Encoded access token.
    """
    return create_token(
        user_id=user_id,
        token_type="access",
        expires_delta=timedelta(
            minutes=ACCESS_TOKEN_EXPIRE_MINUTES
        ),
    )


def create_refresh_token(user_id: int) -> str:
    """
    Create a JWT refresh token for renewing access tokens.

    Args:
        user_id: ID of the user.

    Returns:
        str: Encoded refresh token.
    """
    return create_token(
        user_id=user_id,
        token_type="refresh",
        expires_delta=timedelta(
            days=REFRESH_TOKEN_EXPIRE_DAYS
        ),
    )


def decode_token(
    token: str,
    expected_type: str,
) -> dict | None:
    """
    Decode and validate a JWT token, checking its expected type.

    Args:
        token: Encoded JWT token.
        expected_type: Expected token type.

    Returns:
        dict | None: Decoded token payload if valid and of the expected type,
        otherwise None.
    """
    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],
        )

        if payload.get("type") != expected_type:
            return None

        return payload

    except jwt.InvalidTokenError:
        return None


def create_email_verification_token(user_id: int) -> str:
    """
    Create a JWT token for verifying a user's email address.

    The verification token is valid for 24 hours.

    Args:
        user_id: ID of the user whose email address must be verified.

    Returns:
        str: Encoded email verification token.
    """
    return create_token(
        user_id=user_id,
        token_type="email_verification",
        expires_delta=timedelta(hours=24),
    )
