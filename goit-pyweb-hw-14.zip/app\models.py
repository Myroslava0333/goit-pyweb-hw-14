from sqlalchemy import (
    Column,
    Integer,
    String,
    Date,
    ForeignKey,
    Text,
    Boolean,
)
from sqlalchemy.orm import relationship

from app.database import Base


class User(Base):
    """
    Модель користувача системи.

    Зберігає електронну пошту, хеш пароля, статус верифікації
    та посилання на аватар користувача.

    З одним користувачем може бути пов'язано багато контактів.
    """

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)

    email = Column(
        String(255),
        unique=True,
        index=True,
        nullable=False,
    )

    hashed_password = Column(
        String(255),
        nullable=False,
    )

    is_verified = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    avatar_url = Column(
        String(500),
        nullable=True,
    )

    contacts = relationship(
        "Contact",
        back_populates="user",
        cascade="all, delete-orphan",
    )


class Contact(Base):
    """
    Модель контакту.

    Зберігає ім'я, прізвище, електронну пошту, телефон,
    дату народження та додаткову інформацію.

    Контакт може бути пов'язаний із користувачем системи.
    """

    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True, index=True)

    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    email = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    birthday = Column(Date, nullable=False)
    additional_data = Column(Text, nullable=True)

    user_id = Column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )

    user = relationship(
        "User",
        back_populates="contacts",
    )