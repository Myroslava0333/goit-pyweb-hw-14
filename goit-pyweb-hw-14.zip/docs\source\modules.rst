
Модулі Python
=============

Основні модулі застосунку
-------------------------

.. automodule:: app.database
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.dependencies
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.security
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.auth
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.limiter
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.main
   :members:
   :undoc-members:
   :show-inheritance:

Моделі та схеми
---------------

.. automodule:: app.models
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.schemas
   :members:
   :undoc-members:
   :show-inheritance:

Репозиторій
-----------

.. automodule:: app.repository.contacts
   :members:
   :undoc-members:
   :show-inheritance:

Маршрутизатори
--------------

.. automodule:: app.routers.auth
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.routers.contacts
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: app.routers.users
   :members:
   :undoc-members:
   :show-inheritance:

Сервіси
-------

.. automodule:: app.services.email
   :members:
   :undoc-members:
   :show-inheritance:
