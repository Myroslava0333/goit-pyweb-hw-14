
import os
from io import BytesIO

import cloudinary
import cloudinary.uploader

from dotenv import load_dotenv

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    UploadFile,
    status,
)

from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import get_current_user
from ..models import User


load_dotenv()


router = APIRouter(
    prefix="/users",
    tags=["Users"],
)


cloudinary.config(
    cloud_name=os.getenv("CLOUDINARY_CLOUD_NAME"),
    api_key=os.getenv("CLOUDINARY_API_KEY"),
    api_secret=os.getenv("CLOUDINARY_API_SECRET"),
    secure=True,
)


@router.post("/avatar")
async def update_avatar(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Upload or update the avatar of the currently authenticated user.

    Validates the uploaded image format and size, uploads the image
    to Cloudinary and saves its secure URL in the database.

    Supported formats are JPEG, PNG and WEBP.
    The maximum allowed image size is 5 MB.

    Args:
        file: Image file uploaded by the user.
        db: Database session.
        current_user: Currently authenticated user.

    Returns:
        dict: Success message and URL of the uploaded avatar.

    Raises:
        HTTPException: If the image format is unsupported,
            the file exceeds the size limit, Cloudinary is not configured,
            or the upload operation fails.
    """
    allowed_types = [
        "image/jpeg",
        "image/png",
        "image/webp",
    ]

    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only JPEG, PNG and WEBP images are allowed",
        )

    contents = await file.read()

    if len(contents) > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Image must not exceed 5 MB",
        )

    if not all([
        os.getenv("CLOUDINARY_CLOUD_NAME"),
        os.getenv("CLOUDINARY_API_KEY"),
        os.getenv("CLOUDINARY_API_SECRET"),
    ]):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Cloudinary is not configured",
        )

    try:

        result = cloudinary.uploader.upload(
            BytesIO(contents),
            folder="contacts_avatars",
            public_id=f"user_{current_user.id}",
            overwrite=True,
            resource_type="image",
        )

        current_user.avatar_url = result["secure_url"]

        db.commit()
        db.refresh(current_user)

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Could not upload avatar",
        )

    return {
        "message": "Avatar successfully updated",
        "avatar_url": current_user.avatar_url,
    }
