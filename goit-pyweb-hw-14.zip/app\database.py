
"""
Модуль налаштування підключення до бази даних.

Створює SQLAlchemy engine, фабрику сесій та базовий клас моделей.
Також містить залежність get_db для отримання сесії бази даних
у маршрутах FastAPI.
"""

import os

from dotenv import load_dotenv

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base


load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set in .env")


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
)


SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


Base = declarative_base()


def get_db():
    """
    Створює та надає сесію бази даних.

    Після завершення роботи запиту автоматично закриває сесію.
    """
    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()
